import UIKit

class LoginAccessViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        title = "Acceso" // Esto se muestra en la barra de navegación
    }
}
